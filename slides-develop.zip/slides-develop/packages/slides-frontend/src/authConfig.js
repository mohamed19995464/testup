export const keycloakUrl = 'https://auth.cern.ch/auth';
export const keycloakRealm = 'cern';
export const keycloakClientId = 'slides-frontend';
export const refreshKeycloakToken = true;
