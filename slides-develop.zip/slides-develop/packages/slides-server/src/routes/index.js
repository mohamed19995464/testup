import image from './image';
import presentation from './presentation';
import testBackend from './testBackend';
import wopi from './wopi';

export default {
  image,
  presentation,
  testBackend,
  wopi,
};
