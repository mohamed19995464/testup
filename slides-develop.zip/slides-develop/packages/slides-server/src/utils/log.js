module.exports = (req, res, next) => {
  // console.log("Passed the authentication");
  next();
};
